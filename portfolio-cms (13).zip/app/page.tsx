"use client"

import HeroSection from "../src/components/portfolio/HeroSection"

export default function SyntheticV0PageForDeployment() {
  return <HeroSection />
}